// hello_lib.cpp


#include <string> 
#include "hello_lib.h"

auto lib_help() -> std::string {
    return std::string("lib_help here!");
}
