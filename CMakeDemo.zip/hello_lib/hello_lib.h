// hello_lib.h 


#include <string>

auto lib_help() -> std::string;

