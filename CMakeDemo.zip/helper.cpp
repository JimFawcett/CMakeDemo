// helper.cpp

#include <string> 

auto do_help(const std::string &str) -> std::string {
    return std::string("do_help argument is: ") + str;
}
