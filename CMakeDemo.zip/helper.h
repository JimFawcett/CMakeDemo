// helper.h

#include <string>

auto do_help(const std::string &str) -> std::string;


